<?php

return [
    'name' => 'Binance'
];
